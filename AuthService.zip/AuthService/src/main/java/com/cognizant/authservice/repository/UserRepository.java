package com.cognizant.authservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.authservice.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	
	User findByidAndPassword(int id, String password);

	Optional<User> findByid(int id);

}
