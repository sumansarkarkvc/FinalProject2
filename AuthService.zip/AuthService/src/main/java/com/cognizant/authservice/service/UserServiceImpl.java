package com.cognizant.authservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.authservice.exception.UserAlreadyExistsException;
import com.cognizant.authservice.exception.UserNotFoundException;
import com.cognizant.authservice.model.User;
import com.cognizant.authservice.repository.UserRepository;

@Service("userService")
public class UserServiceImpl implements UserService{
	private UserRepository userRepository;
	@Autowired
	public UserServiceImpl(UserRepository userRepository){
		this.userRepository=userRepository;
	}

	@Override
	public boolean saveUser(User user) throws UserAlreadyExistsException {
		Optional <User> result=userRepository.findByid(user.getId());
		if(result.isPresent())
		{
			throw new UserAlreadyExistsException("User already exists exception");
		}
			userRepository.save(user);
		return true;
	}

	@Override
	public User findByUserIdAndPassword(int userId, String password) throws UserNotFoundException {
		User user=userRepository.findByidAndPassword(userId, password);
		if (user==null)
		{
			throw new UserNotFoundException("User is not a registered user");
		}
		return user;
	}
	
}
