package com.cognizant.authservice.service;

import com.cognizant.authservice.exception.UserAlreadyExistsException;
import com.cognizant.authservice.exception.UserNotFoundException;
import com.cognizant.authservice.model.User;

public interface UserService {
	
	public boolean saveUser(User user) throws UserAlreadyExistsException;
	public User findByUserIdAndPassword(int UserId, String Password) throws UserNotFoundException;

}
